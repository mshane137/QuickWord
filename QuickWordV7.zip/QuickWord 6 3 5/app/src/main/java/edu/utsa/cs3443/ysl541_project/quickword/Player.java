package edu.utsa.cs3443.ysl541_project.quickword;


import android.content.Context;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

public class Player {

    private static int highScore;
    private static int highestStreak;
    private static String username;
    private static int playerHearts = 0;
    private static boolean hardCoreMode = false;
    private static int gameNumber = 0;
    private static int currentScore = 0;
    private static boolean studyMode = false;      // Study mode will be false by default

    /// This is the player constructor, it will hold the players data
        ///     and the players username
    public Player(int highScore, int highestStreak, String username){

        Player.highScore = highScore;
        Player.highestStreak = highestStreak;
        Player.username = username;
    }

        /// Get the players high score
    public static int getHighScore() {

        return highScore;
    }

        /// Get the players highest streak
    public static int getHighestStreak() {

        return highestStreak;
    }

        /// Get the players username
    public static String getUsername() {

        return username;
    }

        /// Get the players hearts
    public static int getPlayerHearts() {
        return playerHearts;
    }

        /// Will return true if player hearts is 0
    public static boolean isHeartsZero() {
        return getPlayerHearts() == 0;
    }

        /// This will check and set if the player received a new high score
    public static boolean isHighScore() {

        if (highScore < currentScore) {
            highScore = currentScore;
            return true;
        }
        return false;
    }

    public static void increaseGameCount() {
        gameNumber++;

    }
        /// This will check and set if the player received a new high streak
    public static boolean isHighStreak() {

        if (highestStreak < gameNumber) {
            highestStreak = gameNumber;
            return true;
        }
        return false;
    }

        /// This will return if hardCoreMode is enabled
    public static boolean isHardCoreMode() {
        return hardCoreMode;
    }

        /// This will toggle hardCoreMode
    public static void toggleHardCoreMode() {
        hardCoreMode = !hardCoreMode;
    }

        /// This calculate the score based on remaining time
    public static void scoreTracker(int time){

        int score = 0;

        if (gameNumber < 4) {                    // If the players streak is less than 5
            score = (150 - (time * 10)) + 100;
        } else if (gameNumber < 10) {            // If the players streak is in range 5 to 9
            score = (450 - (time * 37)) + 200;
        } else if (gameNumber < 15) {            // If the players streak is in range 10 to 15
            score = (900 - (time * 100)) + 400;
        } else{                                       // If the players streak is 15 or greater
            score = (4050 - (time * 675)) + 800;
        }

        score = isHardCoreMode() ? score * 2 : score; // If hardcore then 2x multiplier is enabled
        setCurrentScore(score);
        System.out.println("Player earned: " + getCurrentScore() + " or " + score);


    }
        /// This will set player health and will check if the player lost all their hearts
        ///     With the inputted key it will set hearts or remove 1
        ///     0: reduction of 1 heart ----- 1: Set hearts based on if hardcore either 1 or 3
        ///     Returns true if player lost all hearts and false if they have hearts
    public static boolean setPlayerHearts(int key){
        switch(key){    // This will determine the hearts of the player based on a key
            case 0:
                playerHearts -= 1; // Reduce hearts by 1
                return isHeartsZero();  // Check if hearts are zero
            case 1:
                playerHearts = isHardCoreMode() ? 1 : 3;   // Sets hearts based on mode
                return false;
            default:
                return false;
        }
    }
    /// This will return if studyMode is enabled
    public static boolean isStudyMode() {
        return studyMode;
    }
    /// This will toggle the status of studyMode
    public static void toggleStudyMode() {
        studyMode = !studyMode;
    }

    /// This will return the game number
    public static int getGameNumber() {

        return gameNumber;
    }

    public static int getCurrentScore() {
        return currentScore;
    }

    public static int getMaxTime() {

        if (gameNumber < 4) {
            return 15;
        } else if (gameNumber < 10) {
            return 12;
        } else if (gameNumber < 15) {
            return 9;
        } else {
            return 6;
        }
    }
    public static void setCurrentScore(int score) {
        System.out.println("Updating currentScore. Previous: " + currentScore + ", New: " + score);
        currentScore += score;
    }
    public static int getMaxIntTime() {

        if (gameNumber < 4) {
            return 4;
        } else if (gameNumber < 10) {
            return 3;
        } else if (gameNumber < 15) {
            return 2;
        } else {
            return 1;
        }
    }

    public static void resetScores() {
        currentScore = 0;
        gameNumber = 0;
    }


    public static void updatePlayerFile(Context context) {

        int value = 0; // 0 by default
        String fileName = Player.getUsername() + "_data";

        try { File playerFile = new File(context.getFilesDir(), fileName);
            Scanner dataScanner = new Scanner(playerFile);

            String[] tokens = dataScanner.nextLine().split(",");


            tokens[1] = String.valueOf(Player.getHighScore());       // Update highScore
            tokens[2] = String.valueOf(Player.getHighestStreak());  // Update highestStreak
            value = (Player.isStudyMode())? 1 : 0;
            tokens[3] = String.valueOf(value);   // Update hardCoreMode
            value = (Player.isHardCoreMode())? 1 : 0;
            tokens[4] = String.valueOf(value);      // Update studyMode

            FileOutputStream fos = new FileOutputStream(playerFile);
            // Name,highScore,highestStreak,hardCoreMode,studyMode
            fos.write(String.join(",", tokens).getBytes());
            fos.close();


        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }


}



