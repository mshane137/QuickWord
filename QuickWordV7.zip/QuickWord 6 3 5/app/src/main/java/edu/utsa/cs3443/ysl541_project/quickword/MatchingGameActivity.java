package edu.utsa.cs3443.ysl541_project.quickword;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Objects;
import java.util.Random;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class MatchingGameActivity extends AppCompatActivity {
    private GridLayout gridLayout;
    private TextView scoreText, heartsText;

    private Button firstButton = null;
    private ScheduledExecutorService scheduler;
    private Random random;
    private int matchedPairs = 0; // Track successful matches

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_matching_game);

        // Initialize UI components
        initializeUI();

        scheduler = Executors.newScheduledThreadPool(1);
        random = new Random();

        startNewGame();
        getOnBackPressedDispatcher().addCallback(this, callback);
    }

    private void initializeUI() {
        gridLayout = findViewById(R.id.matching_game_grid);
        scoreText = findViewById(R.id.score_text);
        heartsText = findViewById(R.id.hearts_text);

    }

    private void startNewGame() {
        gridLayout.removeAllViews(); // Clear old buttons
        Game.resetValidPairs(); // Reset valid pairs
        setupWordPairs(); // Create word pairs
        setupButtons(); // Create the grid with buttons
        scoreText.setText(String.valueOf(Player.getCurrentScore()));
        Game.runTimer(Player.getMaxTime(), scheduler, this); //Start the 15-second timer
        runTextTimer(Player.getMaxTime(),scheduler);
    }

    private void setupWordPairs() {
        ArrayList<Word> allWords = Game.getWords(this); //Fetch words based on Study Mode state
        ArrayList<Word> selectedWords = new ArrayList<>();
        int wordCount = 0;
        int index;
        while (wordCount != 3) {
                // Generate a random index
            index = random.nextInt(allWords.size());

                    // Check if the word is already selected
            if (!repeatedWord(selectedWords, allWords.get(index))) {
                selectedWords.add(allWords.get(index)); // Add the word to the selected list
                wordCount++; // Increment the word count
            }
        }



        for (Word word : selectedWords) {
            String wordOne = Player.isStudyMode() ? word.getBaseWord() : word.getSynonyms()[0];
            String wordTwo = Player.isStudyMode() ? word.getDefinition() : word.getAntonyms()[0];
            Game.addValidPair(wordOne, wordTwo);
        }
    }

    private boolean repeatedWord(ArrayList<Word> selectedWords, Word selectedWord) {

        for (Word word : selectedWords) {

            if ((Objects.equals(word.getBaseWord(), selectedWord.getBaseWord()))){

                return true ;
            }
        }
        return false;
    }

    private void setupButtons() {
        ArrayList<String[]> validPairs = Game.getValidPairs(); //Get valid synonym-antonym pairs
        ArrayList<String> allWords = new ArrayList<>();

        //Collect all words for random placement
        for (String[] pair : validPairs) {
            allWords.add(pair[0]); //Add synonym
            allWords.add(pair[1]); //Add antonym
        }
        Collections.shuffle(allWords);// Shuffle for random placement

        //Create buttons for each word
        for (int i = 0; i < 6; i++) {
            Button button = createButton(allWords.get(i));
            gridLayout.addView(button);
        }
    }

    // Handle back button behavior
    OnBackPressedCallback callback = new OnBackPressedCallback(true) {
        @Override
        public void handleOnBackPressed() {
            if (scheduler != null && !scheduler.isShutdown()) {
                Game.stopTimer(scheduler);
            }

            Toast.makeText(MatchingGameActivity.this, "Back To Menu", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(MatchingGameActivity.this, Navigation.class);
            intent.putExtra("Home Key", 1);
            startActivity(intent);
            finish(); // Finish the current activity
        }
    };


    private Button createButton(String word) {
        Button button = new Button(this);
        button.setText(word);
        button.setTag(word);
        button.setBackgroundColor(getColor(android.R.color.darker_gray));


        GridLayout.LayoutParams params = new GridLayout.LayoutParams();
        params.width = 200; // Fixed width (adjust as needed)
        params.height = 200; // Fixed height (adjust as needed)
        params.setMargins(16, 16, 16, 16); // Add spacing between buttons
        params.rowSpec = GridLayout.spec(GridLayout.UNDEFINED, 1, 1f); // Center row
        params.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1, 1f); // Center column


        button.setLayoutParams(params);
        button.setOnClickListener(view -> handleButtonClick(button));
        return button;
    }

    @SuppressLint("SetTextI18n")
    private void handleButtonClick(Button button) {
        if (firstButton == null) {
            // First button clicked
            firstButton = button;
            button.setBackgroundColor(getColor(android.R.color.holo_orange_light)); // Highlight first button
        } else {
            // Second button clicked
            String firstID = firstButton.getTag().toString(); // Get first button's word
            String secondID = button.getTag().toString(); // Get second button's word

            if (Game.IDCheck(firstID, secondID)) {
                // Successful match
                handleSuccessfulMatch(button);
            } else {
                // Incorrect match
                handleMismatch(button);
            }
            firstButton = null; // Reset for the next pair
        }
    }

    @SuppressLint("SetTextI18n")
    private void handleSuccessfulMatch(Button button) {
        // Highlight both buttons as green and disable them
        firstButton.setBackgroundColor(getColor(android.R.color.holo_green_light));
        button.setBackgroundColor(getColor(android.R.color.holo_green_light));
        firstButton.setEnabled(false);
        button.setEnabled(false);

        // Increment matched pairs
        matchedPairs++;

        // Check if all pairs are matched
        if (matchedPairs == 3) {
            //Toast.makeText(this, "You matched all pairs!", Toast.LENGTH_SHORT).show();
            gameCompletion();
        }
    }

    @SuppressLint("SetTextI18n")
    private void handleMismatch(Button button) {
        // Highlight both buttons as red
        firstButton.setBackgroundColor(getColor(android.R.color.holo_red_light));
        button.setBackgroundColor(getColor(android.R.color.holo_red_light));

        // Remove a heart
        if (Player.setPlayerHearts(0)) {
            gameOver(); // End game if no hearts remain
            return;
        }

        heartsText.setText("Hearts: " + Player.getPlayerHearts());

        // Reset button colors after a delay
        new Handler().postDelayed(() -> {
            if (firstButton != null) firstButton.setBackgroundColor(getColor(android.R.color.darker_gray));
            button.setBackgroundColor(getColor(android.R.color.darker_gray));
        }, 500);
    }

    public void runTextTimer(long allottedTime, ScheduledExecutorService scheduler) {
        TextView timerTextView = findViewById(R.id.timer_text_matching);

        if (timerTextView == null) {
            Log.e("runTextTimer", "TextView(s) not found.");
            return;
        }

        long startTime = System.currentTimeMillis();

        Runnable task = () -> {
            long elapsedTime = (System.currentTimeMillis() - startTime) / 1000;
            long remainingTime = allottedTime - elapsedTime;

            if (remainingTime > 0) {
                // Update UI on the main thread
                runOnUiThread(() -> timerTextView.setText(String.valueOf(remainingTime)));
            } else {
                Log.i("runTextTimer", "timer completed");
                scheduler.shutdown(); // Shut down scheduler
            }
        };

        // Schedule the task
        scheduler.scheduleWithFixedDelay(task, 0, 1, TimeUnit.SECONDS);
    }

    private void gameOver() {
        Game.stopTimer(scheduler); // Stop the timers
        Intent intent = new Intent(this, GameOver.class);
        startActivity(intent); // Navigate to the main menu or game over screen
    }



    public void gameCompletion() {

        System.out.println("Next Game");
        Player.scoreTracker(Game.getRemainingTime());
        Player.increaseGameCount();
        Game.stopTimer(scheduler);


        // TODO GAME LAUNCH NAVIGATION

        Intent intent = new Intent(MatchingGameActivity.this, Navigation.class);
        intent.putExtra("Home Key", 2); // Use a key to identify the data
        startActivity(intent);
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (isFinishing()) {
            AudioPlayer.getInstance().stop();
        }
    }
}