package edu.utsa.cs3443.ysl541_project.quickword;

public class Word {

    private final String baseWord;
    private final String[] synonyms;
    private final String[] antonyms;
    private final String definition;



        /// This constructor will be used for Study mode. It will only take the base word
        ///   Plus the word definition
    public Word(String baseWord, String definition) {


        this.baseWord = baseWord;
        this.synonyms = new String[]{"Unassigned"};
        this.antonyms = new String[]{"Unassigned"};
        this.definition = definition;
    }
        /// This constructor will be used for Base/Default mode. It will take an array of strings
        ///     Without a definition
    public Word(String baseWord, String[] synonyms, String[]antonyms) {

        this.baseWord = baseWord;
        this.synonyms = synonyms;
        this.antonyms = antonyms;
        this.definition = "Unassigned";
    }

        /// This will return the base word
    public String getBaseWord(){

        return baseWord;
    }

        /// This will return the definition
    public String getDefinition() {
        return definition;
    }

    /// This will return a list of antonyms
    public String[] getAntonyms(){

        return antonyms;
    }
        /// This will return a list of synonyms
    public String[] getSynonyms(){

        return synonyms;
    }

        /// This will return the length of the baseWord
    public int getBaseWordCount(){

        return baseWord.length();
    }
        /// This will return the length of the definition
    public int getDefinitionWordCount(){

        return definition.length();
    }
        /// Gets a random word from antonyms or synonyms
    public String getAntOrSyn(int coinFlip, int wordChoice){
        String[] string;
        if (coinFlip == 0 ){string = getSynonyms();}
        else {string = getAntonyms();}
        return string[wordChoice];

    }



}
