package edu.utsa.cs3443.ysl541_project.quickword;

import android.content.Intent;
import android.content.res.AssetManager;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.OnBackPressedCallback;
import androidx.annotation.ColorInt;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.util.Scanner;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });





        //TODO THIS WILL LOAD ALL THE FILE IO/OU SHIITAKE


        //TODO THIS WILL ASK FOR USERNAME IF NOT INPUTTED YET

        // Handle back button behavior
        OnBackPressedCallback callback = new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                // Show a message when back is pressed
                Toast.makeText(MainActivity.this, "Back To Menu", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(MainActivity.this, Navigation.class);
                intent.putExtra("Home Key", 1);
                startActivity(intent);
                finish(); // Finish the current activity
            }
        };
        getOnBackPressedDispatcher().addCallback(this, callback);

        try {
            loadDefaultWords(this);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        EditText inputWord = findViewById(R.id.inputUser);
        Button submitButton = findViewById(R.id.submitButton);
        submitButton.setBackgroundColor(Color.rgb(236,217,172));
        submitButton.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View v) {

                String word = inputWord.getText().toString();



                if (doesPlayerDataExist(word + "_data")) {

                    Toast.makeText(MainActivity.this, "Data found for " + word + "_data", Toast.LENGTH_SHORT).show();
                    try {
                        loadPlayerData(MainActivity.this,word);
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }
                else {
                    createNewPlayerData(MainActivity.this,word);

                    Toast.makeText(MainActivity.this, "Created new profile for " + word + "_data", Toast.LENGTH_SHORT).show();
                }

                //TODO launch navigation
                Player.setPlayerHearts(1);
                Player.resetScores();
                Intent intent = new Intent(MainActivity.this, Navigation.class);
                intent.putExtra("Home Key", 1); // Use a key to identify the data
                startActivity(intent);
            }
        });

    }


        /// This will create a new file that houses the players data if their data does not exist
    public void createNewPlayerData(MainActivity mainActivity, String playerName) {
        String fileName = playerName + "_data";
        File playerFile = new File(getFilesDir(), fileName);
        try {


            FileOutputStream fos = new FileOutputStream(playerFile);
            //Name,highScore,highestStreak,hardCoreMode,studyMode
            fos.write((playerName + "," + "0" + "," + "0" + "," + "0" + "," + "0").getBytes());
            fos.close();

            loadPlayerData(mainActivity, playerName);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }

        /// This will gather and load the players data if their file does exist
    public void loadPlayerData(MainActivity mainActivity, String playerUser) throws IOException {
        String[] tokens;
        String customWordFile = playerUser + "_custom_words.txt";

        try (FileInputStream playerData = openFileInput(playerUser + "_data");)
            {

            Scanner dataScanner = new Scanner(playerData);
            tokens = dataScanner.nextLine().split(",");
                // Name,highScore,highestStreak,hardCoreMode,studyMode
            new Player(Integer.parseInt(tokens[1]), Integer.parseInt(tokens[2]), tokens[0]);

                // Sets if the player had study mode enabled
                switch (Integer.parseInt(tokens[3])) {
                    case 1:
                        if (!(Player.isStudyMode())) {Player.toggleStudyMode();}
                        break;
                    case 0:
                        if (Player.isStudyMode()) {Player.toggleStudyMode();}
                        break;

                }

                // Sets if the player had hardcore mode enabled
            switch (Integer.parseInt(tokens[4])) {
                case 1:
                    if (!(Player.isHardCoreMode())) {Player.toggleHardCoreMode();}
                    break;
                case 0:
                    if (Player.isHardCoreMode()) {Player.toggleHardCoreMode();}
                    break;

            }

        } catch (IOException e) {

            Log.e("MainActivity", "Error reading player data file " + playerUser, e );

        }

        /// Loads custom word file if found
        if (doesPlayerDataExist(customWordFile)){
            Game.clearWordList();
            File playerFile = new File(getFilesDir(), customWordFile);
            Log.i("MainActivity", " Found the file: " + customWordFile);
            Game.loadCustomWords(playerFile);
        }
        else {
            Log.i("MainActivity", " Could not find the file: " + customWordFile);

        }

    }
    public boolean doesPlayerDataExist(String playerData) {
        File data = new File(getFilesDir(), playerData);
        return data.exists();
    }

    public void loadDefaultWords(MainActivity mainActivity) throws IOException {
        AssetManager manager = mainActivity.getAssets();

        String[] tokens;
        String[] synonymTokens;
        String[] antonymTokens;

        try (InputStream defaultModeFile = manager.open("default_mode.txt");)
        {
            Scanner wordScanner = new Scanner(defaultModeFile);
            wordScanner.nextLine();
            while (wordScanner.hasNextLine()) {
                // word,synonyms1/synonym2/synonym3,antonyms1/antonym2/antonym3,definition
                // (String baseWord, String[] synonyms, String[]antonyms)
                tokens = wordScanner.nextLine().split(",");

                synonymTokens = tokens[1].split("/");
                antonymTokens = tokens[2].split("/");


                Word word = new Word(tokens[0],synonymTokens,antonymTokens);
                Game.appendWord(word);
                Log.i("MainActivity", Game.getWordCount() + " words loaded successfully.");

            }

            wordScanner.close();
        } catch (IOException e) {

            Log.e("MainActivity", "Error reading default data file " + "default_mode.txt", e );

        }



    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (isFinishing()) {
            AudioPlayer.getInstance().stop();
        }
    }
}
