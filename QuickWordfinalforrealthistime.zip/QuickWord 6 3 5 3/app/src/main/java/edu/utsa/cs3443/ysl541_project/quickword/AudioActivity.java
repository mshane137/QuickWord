package edu.utsa.cs3443.ysl541_project.quickword;

import android.media.AudioManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.SeekBar;
import androidx.appcompat.app.AppCompatActivity;

    /// This holds the needed functions for the audio player
public class AudioActivity extends AppCompatActivity {
    private AudioPlayer audioPlayer;
    private AudioManager audioManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_audio);

        audioPlayer = AudioPlayer.getInstance();
        audioPlayer.initialize(this);

        audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);

        Button btnPlay = findViewById(R.id.btnPlay);
        Button btnPause = findViewById(R.id.btnPause);
        Button btnStop = findViewById(R.id.btnStop);
        SeekBar volumeSeekBar = findViewById(R.id.seekBar); // Using the existing SeekBar

        btnPlay.setOnClickListener(v -> audioPlayer.play());
        btnPause.setOnClickListener(v -> audioPlayer.pause());
        btnStop.setOnClickListener(v -> audioPlayer.stop());

        // Set up the SeekBar to control the volume
        setUpVolumeSeekBar(volumeSeekBar);
    }

    private void setUpVolumeSeekBar(SeekBar volumeSeekBar) {
        int maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        int currentVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);

        volumeSeekBar.setMax(maxVolume);
        volumeSeekBar.setProgress(currentVolume);

        volumeSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) {
                    audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, progress, 0);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) { }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) { }
        });
    }

    @Override
    protected void onPause() {
        super.onPause();

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
}