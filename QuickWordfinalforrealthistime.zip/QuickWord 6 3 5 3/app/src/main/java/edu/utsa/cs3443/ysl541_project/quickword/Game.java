package edu.utsa.cs3443.ysl541_project.quickword;

import android.content.Context;
import android.content.Intent;
import android.util.Log;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

        /// Holds all the functions for games
public class Game {

    private final int gameType;
    private final int gameID;
    private static final ArrayList<Word> words = new ArrayList<>();

    private static final ArrayList<Word> customWords = new ArrayList<>();
    private static ArrayList<String[]> validPairs;

    static int time;
    private static long startTime;

    public Game(int gameType, int gameID) {
        this.gameType = gameType;
        this.gameID = gameID;
    }

            /// clears the custom word list
    public static void clearWordList() {
        customWords.clear();
    }

            /// returns game ID
    public int getGameID() {
        return gameID;
    }

            /// returns game type
    public int getGameType() {
        return gameType;
    }

            /// This will return an array list of words based on if its study mode or not
    public static ArrayList<Word> getWords(Context context) {
        if (Player.isStudyMode()) {
            Log.i("Game", "Returned Custom Words");
            return customWords;
        } else {
            Log.i("Game", "Returned Default Words");
            return words;
        }
    }

            /// This will return the word count of either default words or custom words
    public static int getWordCount() {
        if (Player.isStudyMode()) {
            Log.i("Game", "There are: " + customWords.size() + " custom words");
            return customWords.size();
        } else {
            Log.i("Game", "There are: " + words.size() + " base words");
            return words.size();
        }
    }

            /// This will remove a word from the custom words list
    public static void removeWord(String word) {

        customWords.removeIf(words -> words.getBaseWord().equals(word));

    }

            /// This will append a word to either the custom words or the default word list
    public static void appendWord(Word word) {

        if (Player.isStudyMode()) {
           customWords.add(word);
        } else {
            words.add(word);
        }

    }

            /// This will run the in game timer. Once the time has run out it will initialize a game
            /// Over
    public static void runTimer(long allottedTime, ScheduledExecutorService scheduler, Context context) {
        startTime = System.currentTimeMillis();

        Runnable task = () -> {
            long elapsedTime = (System.currentTimeMillis() - startTime) / 1000;
            long remainingTime = allottedTime - elapsedTime;

            if (remainingTime > 0) {    // Will send a countdown to the log
                System.out.println("Time remaining: " + remainingTime + " seconds");
                Game.time = (int) remainingTime;

            } else {    // Once the time has run out
                scheduler.shutdown();
                Intent intent = new Intent(context, GameOver.class);
                context.startActivity(intent);
            }
        };

        scheduler.scheduleWithFixedDelay(task, 0, 1, TimeUnit.SECONDS);
    }

            /// This will stop the timer thread
    public static void stopTimer(ScheduledExecutorService scheduler) {
        System.out.println("Timer Stopped");
        scheduler.shutdownNow();
    }

            /// This will retrieve the remaining time left in the timer
    public static int getRemainingTime() {
        long elapsedTime = (System.currentTimeMillis() - startTime) / 1000;
        return (int) Math.max(Player.getMaxTime() - elapsedTime, 0);
    }

            /// This will check the ID of the valid pairs
    public static boolean IDCheck(String IDA, String IDB) {
        for (String[] pair : validPairs) {
            if ((pair[0].equals(IDA) && pair[1].equals(IDB)) ||
                    (pair[0].equals(IDB) && pair[1].equals(IDA))) {
                return true;
            }
        }
        return false;
    }

            /// This will add the ID's to the valid pairs
    public static void addValidPair(String leftID, String rightID) {
        validPairs.add(new String[]{leftID, rightID});
    }

            /// This will reset the valid pairs
    public static void resetValidPairs() {
        if (validPairs != null) {
            validPairs.clear();
        } else {
            validPairs = new ArrayList<>();
        }
    }

            /// This will retrieve the valid pairs
    public static ArrayList<String[]> getValidPairs() {
        return new ArrayList<>(validPairs);
    }

            /// This will load all custom words from file
    static void loadCustomWords(File file) {

         //If file doesn't exist, return an empty list
        if (!file.exists()) return;

            // Read file with try-with-resources for automatic resource management
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",", 2); //Split into word and definition
                if (parts.length == 2) {
                    String word = parts[0].trim();
                    String definition = parts[1].trim();

                        // Validate that both word and definition are non-empty
                    if (!word.isEmpty() && !definition.isEmpty()) {
                        appendWord(new Word(word, definition));
                        Log.i("Game", Game.getWordCount() + " custom words loaded successfully.");
                    } else {
                        Log.e("loadCustomWords", "Skipping entry with empty word/definition: " + line);
                    }
                } else {
                    Log.e("loadCustomWords", "Invalid line format: " + line);
                }
            }
        } catch (Exception e) {
            Log.e("loadCustomWords", "Error reading custom_words.txt", e);
        }


    }
}
