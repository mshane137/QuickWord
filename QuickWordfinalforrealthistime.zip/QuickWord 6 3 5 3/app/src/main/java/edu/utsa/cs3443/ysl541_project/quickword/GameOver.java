package edu.utsa.cs3443.ysl541_project.quickword;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import org.w3c.dom.Text;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

public class GameOver extends AppCompatActivity {
    Intent intent;
    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_game_over);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

            // Establishes the UI
        TextView gameOverText = findViewById(R.id.textView2);
        gameOverText.setText("Game Over!");
        gameOverText.setTextSize(15);


        TextView streakText = findViewById(R.id.streak_score);
        streakText.setText("You lasted " + String.valueOf(Player.getGameNumber()) + " Rounds!");

        TextView scoreText = findViewById(R.id.player_score);
        scoreText.setText("Score: " + String.valueOf(Player.getCurrentScore()));
        System.out.println(Player.getCurrentScore());

            // Checks if the player got a high score
        if (Player.isHighScore()){

            TextView highScore = new TextView(this);
            highScore.setText("New High Score!!");
            highScore.setWidth(scoreText.getWidth());
            highScore.setHeight(scoreText.getHeight());
        }
            // Checks if the player has a new highest streak
        if (Player.isHighStreak()) {
            TextView highStreak = new TextView(this);
            highStreak.setText("New Highest Streak!");
            highStreak.setWidth(streakText.getWidth());
            highStreak.setHeight(streakText.getHeight());
        }

            // Makes the buttons for play again and return home
        Button home_button = findViewById(R.id.home_button);
        Button play_button = findViewById(R.id.play_again);
        home_button.setText("Return Home");
        play_button.setText("Play Again");

            /// Updates the players file
        Player.updatePlayerFile(this);

            // resets player scores
        Player.resetScores();
        Player.setPlayerHearts(1);
        home_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // TODO GO HOME
                intent = new Intent(GameOver.this, Navigation.class);
                intent.putExtra("Home Key", 1); // Use a key to identify the data
                startActivity(intent);

            }
        });


        play_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // TODO REPLAY
                intent = new Intent(GameOver.this, Navigation.class);
                intent.putExtra("Home Key", 2); // Use a key to identify the data
                startActivity(intent);
            }
        });
        getOnBackPressedDispatcher().addCallback(this, callback);
    }

    // Handle back button behavior
    OnBackPressedCallback callback = new OnBackPressedCallback(true) {
        @Override
        public void handleOnBackPressed() {
            // Show a message when back is pressed
            Toast.makeText(GameOver.this, "Back To Menu", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(GameOver.this, Navigation.class);
            intent.putExtra("Home Key", 1);
            startActivity(intent);
            finish(); // Finish the current activity
        }
    };


    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (isFinishing()) {
            AudioPlayer.getInstance().stop();
        }
    }

}