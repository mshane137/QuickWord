package edu.utsa.cs3443.ysl541_project.quickword;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.io.Serializable;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Random;
import java.util.ArrayList;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class SpellingGame extends AppCompatActivity {
    Random random = new Random();
    public static int numberPos = 0;    // MAKE SURE THIS IS RESET AFTER EVERY GAME!!
    ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);

    ScheduledExecutorService schedulerSecond = Executors.newScheduledThreadPool(2);
    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_spelling_game);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
            // This will keep track of the letter position
        numberPos = 0;
            // Sets up the games UI
        TextView scoreDisplay = findViewById(R.id.scoreTextSpellingGame);
        TextView heartDisplay = findViewById(R.id.heartsTextSpellingGame);
        heartDisplay.setText(String.valueOf(Player.getPlayerHearts()));
        scoreDisplay.setText(String.valueOf(Player.getCurrentScore()));
        System.out.println(Player.getCurrentScore() + "Score");
            // Sets upo grid
        GridLayout gridLayout = findViewById(R.id.gridLayout);
        gridLayout.removeAllViews();
        TextView wordDisplay = findViewById(R.id.wordDisplay);
        wordDisplay.setText("");
        TextView definitionDisplay = findViewById(R.id.definitionDisplay);
                // This will select the word
        String[] selectedWord = wordSelection();
        System.out.println(selectedWord[1]);
        definitionDisplay.setText("A Synonym for: " + selectedWord[1]);
        Log.i("Spelling", "Word selected is: " + selectedWord[0]);
        Log.i("Spelling", "Definition selected is: " + selectedWord[1]);

            // Scrambles Word
        String shuffledWord = wordScrambler(selectedWord[0]);



        getOnBackPressedDispatcher().addCallback(this, callback);

        for (int i = 0; i < 16; i++) {
            Button button = getButton(shuffledWord, i, selectedWord[0], scheduler);

            gridLayout.addView(button);
        }

        runTextTimer(Player.getMaxTime(),schedulerSecond);

        Game.runTimer(Player.getMaxTime(),scheduler, this);

    }

    // Handle back button behavior
    OnBackPressedCallback callback = new OnBackPressedCallback(true) {
        @Override
        public void handleOnBackPressed() {
            if (scheduler != null && !scheduler.isShutdown()) {
                Game.stopTimer(scheduler);
            }
            // Show a message when back is pressed
            Toast.makeText(SpellingGame.this, "Back To Menu", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(SpellingGame.this, Navigation.class);
            intent.putExtra("Home Key", 1);
            startActivity(intent);
            finish(); // Finish the current activity
        }
    };

            /// This will create the buttons for the game
    @NonNull
    private Button getButton(String shuffledWord, int i, String word, ScheduledExecutorService scheduler) {
        TextView wordDisplay = findViewById(R.id.wordDisplay);
        TextView heartTextView = findViewById(R.id.heartsTextSpellingGame);
        Button button = new Button(this);
        button.setText(String.valueOf(shuffledWord.charAt(i))); // Set button text
        button.setBackgroundColor(Color.WHITE);

                // Set a listener for each button
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Button clickedButton = (Button) v;

                        // If the player is correct
                if (checkLetter((clickedButton.getText()).charAt(0),numberPos, word)) {
                    String letter = Character.toString(clickedButton.getText().charAt(0));
                    clickedButton.setEnabled(false);
                    clickedButton.setBackgroundColor(Color.GREEN);
                    numberPos++;
                    checkCompletion(numberPos, word.length());
                    wordDisplay.append(letter);
                }
                else {      // If the player is incorrect
                    clickedButton.setBackgroundColor(Color.RED);
                    boolean dead = Player.setPlayerHearts(0);
                    heartTextView.setText(String.valueOf(Player.getPlayerHearts()));
                    new android.os.Handler().postDelayed(() -> {
                        clickedButton.setBackgroundColor(Color.WHITE);
                    }, 500);

                    if (dead) {     // IF the player loses all health
                        Game.stopTimer(scheduler);
                        Game.stopTimer(schedulerSecond);
                        numberPos = 0;

                        Intent intent = new Intent(SpellingGame.this, GameOver.class);
                        startActivity(intent);

                    }

                }

            }
        });
        return button;
    }


        /// Gets the word selection for the Spelling game and places them in a string to be used
    public String[] wordSelection() {

        String[] wordSelection = new String[2];
        try{
            if (Game.getWordCount() == 0) {
                throw new IllegalArgumentException("Empty Word List");
            }
            int randIntRange = random.nextInt(Game.getWordCount()); // Gets a random count from the total word list
            ArrayList<Word> words = Game.getWords(this);    // gets the word arraylist
            Word word = words.get(randIntRange);        // selects a word at random

            if (Player.isStudyMode()){  // If the player is in studyMode

                wordSelection[0] = word.getBaseWord();
                wordSelection[1] = word.getDefinition();
            }
            else {                      // Else if the player is not in studyMode
                wordSelection[0] = word.getAntOrSyn(random.nextInt(2),random.nextInt(3));
                do {
                    wordSelection[1] = word.getAntOrSyn(random.nextInt(2), random.nextInt(3));

                } while (!(Objects.equals(wordSelection[0], wordSelection[1])));    // Makes sure both words don't match
            }
            } catch (IllegalArgumentException e) {  // catch if the word list is empty

                System.out.println("Error: " + e.getMessage());
            }

        return wordSelection;
    }

        /// Scrabbles the word and fills the empty space with random letters
    public String wordScrambler(String word){

        StringBuilder scrambledWords = new StringBuilder();

        for (char c : word.toCharArray()) {     // Shuffle the base word
            scrambledWords.append(c);
        }
        while (scrambledWords.length() < 16) {  // Add random letters to word till 16
            scrambledWords.append((char) (random.nextInt(26) + 'a'));
        }
        List<Character> scrambledList = new ArrayList<>();
        for (char c : scrambledWords.toString().toCharArray()) {    // Add those letters to a list
            scrambledList.add(c);
        }
        Collections.shuffle(scrambledList); // Shuffles list

        scrambledWords.setLength(0); // Clears scrambledWords
        for (char c : scrambledList) {  // rebuilds the string
            scrambledWords.append(c);
        }

        return scrambledWords.toString();


    }

            /// Checks if the game is complete
    public void checkCompletion(int numberPos, int wordLength){

        if (numberPos == wordLength) {

            gameCompletion();
        }
    }

        /// If the game is complete launches next mini game
    public void gameCompletion() {

        System.out.println("Next Game");
        Player.scoreTracker(Game.getRemainingTime());
        Player.increaseGameCount();
        Game.stopTimer(scheduler);
        Game.stopTimer(schedulerSecond);


        Intent intent = new Intent(SpellingGame.this, Navigation.class);
        intent.putExtra("Home Key", 2); // Use a key to identify the data
        startActivity(intent);
    }

            /// Checks if the selected letters are correct
    public boolean checkLetter(char letterA, int letterPos, String word) {

        System.out.println("Character at " + letterPos + " is " + word.charAt(letterPos));
        System.out.println("Letter A is " + letterA);
        boolean b = Character.toLowerCase(letterA) == Character.toLowerCase(word.charAt(letterPos));
        if (b) {
            System.out.println(letterA + " = " + word.charAt(letterPos));
        }
        return b;

    }

        /// Runs the timer for the clock
    public void runTextTimer(long allottedTime, ScheduledExecutorService scheduler) {
        // Find views
        TextView timerTextView = findViewById(R.id.timerTextSpellingGame);


        // Check for null references
        if (timerTextView == null) {
            Log.e("runTextTimer", "TextView(s) not found.");
            return;
        }

        System.out.println("MiniTimer started");

        // Timer logic
        long startTime = System.currentTimeMillis();

        Runnable task = () -> {
            long elapsedTime = (System.currentTimeMillis() - startTime) / 1000;
            long remainingTime = allottedTime - elapsedTime;

            if (remainingTime > 0) {
                // Update UI on the main thread
                runOnUiThread(() -> {
                    timerTextView.setText(String.valueOf(remainingTime));

                });
            } else {
                // Handle timer completion if necessary
                Log.i("runTextTimer", "timer completed");
                scheduler.shutdown(); // Shut down scheduler to clean up
            }
        };

        // Schedule the task
        scheduler.scheduleWithFixedDelay(task, 0, 1, TimeUnit.SECONDS);
    }


}