package edu.utsa.cs3443.ysl541_project.quickword;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Random;

public class Navigation extends AppCompatActivity {
    Random random = new Random();
    private CountDownTimer countDownTimer;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);

                /// This is see if the player came from the title screen or is going straight
                /// into another game
        int key = getIntent().getIntExtra("Home Key", 0);
        switch (key) {
            case 1: // Goes into the home screen
                setContentView(R.layout.activity_navigation);
                Player.setPlayerHearts(1);
                break;
            case 2: // Goes into intermission
                setContentView(R.layout.activity_navi_intermission);
                break;
            case -1:
                Log.e("Navigation", "Error: Did not get available key");
                finish();
                return;
            default:
                Log.e("Navigation", "Error: Did not get any known value");
                finish();
                return;
        }


        View mainView = findViewById(R.id.main);
        if (mainView != null) {
            ViewCompat.setOnApplyWindowInsetsListener(mainView, (v, insets) -> {
                Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
                v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
                return insets;
            });
        } else {
            Log.e("Navigation", "Error: R.id.main view not found");
        }
            // Makes sure that it goes to intermission
        if (key == 2) {
            gameLauncher();
        }

                // Button set up
        Button gameStart = findViewById(R.id.game_start);
        Button recordsButton = findViewById(R.id.records_button);
        Button optionButton = findViewById(R.id.options_button);
        Button audioButton = findViewById(R.id.audio_button);
        Button infoButton = findViewById(R.id.info_button);
        Button creditsButton = findViewById(R.id.credits_button);

            // Button for Game Start
        if (gameStart != null) {
            gameStart.setOnClickListener(v -> {
                if (Player.isStudyMode() && Game.getWordCount() < 6) {
                    Log.i("Navigation", "Disabled Study Mode: not enough words!");
                    Toast.makeText(this, "Disabled Study Mode, less than 6 words!", Toast.LENGTH_SHORT).show();
                    Player.toggleStudyMode();
                    Player.updatePlayerFile(this);
                    if (Player.isStudyMode()) {
                        Log.e("Navigation", "Study Mode!");
                    }

                }

                setContentView(R.layout.activity_navi_intermission);



                gameLauncher();
            });
        } else {
            Log.e("Navigation", "Game Start Button not found!");
        }

            // Button for records
        if (recordsButton != null) {
            recordsButton.setOnClickListener(v -> {
                Intent intent = new Intent(Navigation.this, RecordsActivity.class);
                startActivity(intent);
            });
        } else {
            Log.e("Navigation", "Records Button not found!");
        }
            // Button for options
        if (optionButton != null) {
            optionButton.setOnClickListener(v -> {
                Intent intent = new Intent(Navigation.this, SettingsActivity.class);
                startActivity(intent);
            });
        } else {
            Log.e("Navigation", "Settings Button not found!");
        }

            // Button for Audio
        if (audioButton != null) {
            audioButton.setOnClickListener(v -> {
                Intent intent = new Intent(Navigation.this, AudioActivity.class);
                startActivity(intent);
            });
        } else {
            Log.e("Navigation", "Audio Button not found!");
        }

            // Button  for info
        if (infoButton != null) {
            infoButton.setOnClickListener(v -> {
                Intent intent = new Intent(Navigation.this, InfoActivity.class);
                startActivity(intent);
            });
        } else {
            Log.e("Navigation", "Info Button not found!");
        }

            // Button for Credits
        if (creditsButton != null) {
            creditsButton.setOnClickListener(v -> {
                Intent intent = new Intent(Navigation.this, CreditsActivity.class);
                startActivity(intent);
            });
        } else {
            Log.e("Navigation", "Credits Button not found!");
        }

        getOnBackPressedDispatcher().addCallback(this, callback);
    }

        // Game launcher
    public void gameLauncher() {
        TextView timer = findViewById(R.id.int_timer);

        int countdownTime = (Player.getMaxIntTime() * 1000) + 500;

        countDownTimer = new CountDownTimer(countdownTime, 1000) {
            @SuppressLint("SetTextI18n")
            @Override
            public void onTick(long millisUntilFinished) {
                int remainingTime = (int) millisUntilFinished / 1000;
                if (remainingTime > 4) {
                    if (timer != null) timer.setText("Ready?");
                }
                if (timer != null) timer.setText(remainingTime + "!");
            }

            @SuppressLint("SetTextI18n")
            @Override
            public void onFinish() {
                if (timer != null) timer.setText("GO!");
                coinFlip();
            }
        };
        countDownTimer.start();
    }

        // Coin flip for the next game mode
    public void coinFlip() {
        int coinFlip;
        coinFlip = random.nextInt(2);
        Intent intent;
        switch (coinFlip) {
            case 0:
                // Goes to matching

                intent = new Intent(this, MatchingGameActivity.class);
                startActivity(intent);
                break;
            case 1:
                // Goes to spelling

                intent = new Intent(this, SpellingGame.class);
                startActivity(intent);
                break;

        }
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    // Handle back button behavior
    OnBackPressedCallback callback = new OnBackPressedCallback(true /* enabled by default */) {
        @Override
        public void handleOnBackPressed() {
            if (countDownTimer != null) {
                countDownTimer.cancel();
                Log.d("Navigation", "Timer stopped when back button pressed.");
            }
            // Show a message when back is pressed
            Toast.makeText(Navigation.this, "Back To Menu", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(Navigation.this, Navigation.class);
            intent.putExtra("Home Key", 1); // Pass key for activity_navigation
            startActivity(intent);
            finish(); // Finish the current activity
        }
    };

    @Override
    protected void onDestroy() {
        super.onDestroy();


        if (isFinishing()) {
            AudioPlayer.getInstance().stop();
        }
    }
}
