package edu.utsa.cs3443.ysl541_project.quickword;

import android.content.Context;
import android.media.MediaPlayer;

public class AudioPlayer {
    private static AudioPlayer instance;
    private MediaPlayer mediaPlayer;

    private AudioPlayer() { }

    public static synchronized AudioPlayer getInstance() {
        if (instance == null) {
            instance = new AudioPlayer();
        }
        return instance;
    }

    public void initialize(Context context) {
        if (mediaPlayer == null) {
            mediaPlayer = MediaPlayer.create(context, R.raw.intro); // Replace 'intro' with your file name
            mediaPlayer.setLooping(true); // Enable infinite looping
        }
    }

    public void play() {
        if (mediaPlayer != null && !mediaPlayer.isPlaying()) {
            mediaPlayer.start();
        }
    }

    public void pause() {
        if (mediaPlayer != null && mediaPlayer.isPlaying()) {
            mediaPlayer.pause();
        }
    }
    public boolean isPlaying() {
        return mediaPlayer != null && mediaPlayer.isPlaying();
    }

    public void stop() {
        if (mediaPlayer != null) {
            mediaPlayer.stop();
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }
}