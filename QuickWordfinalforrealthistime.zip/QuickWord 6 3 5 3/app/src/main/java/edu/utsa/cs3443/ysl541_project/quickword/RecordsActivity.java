package edu.utsa.cs3443.ysl541_project.quickword;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

        /// Displays players records
public class RecordsActivity extends AppCompatActivity {
    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_records);

        TextView playerName = findViewById(R.id.player_name);
        TextView highScore = findViewById(R.id.high_score);
        TextView highStreak = findViewById(R.id.high_streak);

        if (playerName != null) playerName.setText(Player.getUsername());
        if (highScore != null) highScore.setText("High score: " + Player.getHighScore());
        if (highStreak != null) highStreak.setText("Highest Streak: " + Player.getHighestStreak());
    }
}