package edu.utsa.cs3443.ysl541_project.quickword;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.AssetManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class SettingsActivity extends AppCompatActivity {

    private final ArrayList<String> customWords = new ArrayList<>();
    private WordListAdapter adapter;

    @SuppressLint("NotifyDataSetChanged")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        // Initialize switches
        SwitchCompat studyModeSwitch = findViewById(R.id.switch_study_mode);
        SwitchCompat hardcoreModeSwitch = findViewById(R.id.switch_hardcore_mode);

        // Initialize word input and buttons
        EditText wordInput = findViewById(R.id.word_input);
        EditText definitionInput = findViewById(R.id.definition_input);

        // Initialize RecyclerView
        RecyclerView wordListView = findViewById(R.id.word_list);
        wordListView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new WordListAdapter(customWords);
        wordListView.setAdapter(adapter);

        // Get fileName
        String playerWordData = (Player.getUsername() + "_custom_words.txt");


        // Load existing custom words
        File playerFile = getOrCreateCustomWordsFile(this, playerWordData);

        // Set initial visibility for Study Mode fields and RecyclerView
        toggleStudyModeFields(Player.isStudyMode());
         // Hidden by default

        toggleRecyclerViewVisibility(); // RecyclerView visibility depends on data

        // Set initial states based on Player class
        studyModeSwitch.setChecked(Player.isStudyMode());
        hardcoreModeSwitch.setChecked(Player.isHardCoreMode());

        if (Player.isStudyMode()) {
            studyModeSwitch.setChecked(true);
        }

            /// Toggle Study Mode
        studyModeSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            Player.toggleStudyMode();

            toggleStudyModeFields(isChecked); // Show or hide fields
            Toast.makeText(this, "Study Mode " + (isChecked ? "Enabled" : "Disabled"), Toast.LENGTH_SHORT).show();
            Player.updatePlayerFile(this);
        });

        if (Player.isHardCoreMode()) {
            hardcoreModeSwitch.setChecked(true);
        }

            /// Toggle Hardcore Mode
        hardcoreModeSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            Player.toggleHardCoreMode();
            Toast.makeText(this, "Hardcore Mode " + (isChecked ? "Enabled" : "Disabled"), Toast.LENGTH_SHORT).show();
            Player.updatePlayerFile(this);
        });

            /// Add Word
        Button addWordButton = findViewById(R.id.add_word_button);
        addWordButton.setOnClickListener(v -> {
            String customWord = wordInput.getText().toString().trim();
            String definition = definitionInput.getText().toString().trim();
            if (!customWord.isEmpty() && !definition.isEmpty() && (customWord.length() < 17)) {
                if (customWords.contains(customWord)) {
                    Toast.makeText(this, "Word already exists!", Toast.LENGTH_SHORT).show();
                } else {
                    Word word = new Word(customWord,definition);
                    Game.appendWord(word);
                    customWords.add(customWord);
                    adapter.notifyDataSetChanged();
                    saveWordToFile(playerFile, customWord, definition);
                    wordInput.setText("");
                    definitionInput.setText("");
                    toggleRecyclerViewVisibility();
                    Toast.makeText(this, "Word added!", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "Both fields are required!", Toast.LENGTH_SHORT).show();
            }
        });

            /// Delete Word
        Button deleteWordButton = findViewById(R.id.delete_word_button);
        deleteWordButton.setOnClickListener(v -> {
            String customWord = wordInput.getText().toString().trim();
            if (customWords.contains(customWord)) {
                Game.removeWord(customWord);
                customWords.remove(customWord);
                deleteWordFromFile(playerFile,customWord);
                adapter.notifyDataSetChanged();
                wordInput.setText("");
                toggleRecyclerViewVisibility();
                Toast.makeText(this, "Word deleted!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Word not found!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    //Utility method to toggle visibility of Study Mode fields with animation
    private void toggleStudyModeFields(boolean isVisible) {

        View studyModeSection = findViewById(R.id.study_mode_section);
        if (isVisible) {
            studyModeSection.setVisibility(View.VISIBLE);
            studyModeSection.setAlpha(0f);
            studyModeSection.animate().alpha(1f).setDuration(300).start();
        } else {
            studyModeSection.animate().alpha(0f).setDuration(300).withEndAction(() ->
                    studyModeSection.setVisibility(View.GONE)).start();
        }
    }

    /////////////

    public boolean doesPlayerWordDataExist(String playerData) {
        File data = new File(getFilesDir(), playerData);
        return data.exists();
    }





    //Utility method to toggle RecyclerView visibility based on data
    private void toggleRecyclerViewVisibility() {
        RecyclerView wordListView = findViewById(R.id.word_list);
        if (customWords.isEmpty()) {
            wordListView.setVisibility(View.GONE);
        } else {
            wordListView.setVisibility(View.VISIBLE);
        }
    }

    //Ensure custom_words.txt exists
    private File getOrCreateCustomWordsFile(Context context, String playerWordData) {
        File playerFile = new File(context.getFilesDir(), playerWordData);
            // This checks to see if the players word data exists
        if (doesPlayerWordDataExist(playerWordData)) {
                // If exists
            try { Game.loadCustomWords(playerFile);
                Toast.makeText(this, "Word Data found for " + Player.getUsername(), Toast.LENGTH_SHORT).show();
                loadCustomWords(playerFile);
            } catch (Exception e) {
                Log.e("SettingsActivity", "Error loading " + Player.getUsername() + "_custom_words.txt", e);
            }

        }
        else {
                // Creates a new file for the players word data
                Toast.makeText(this, "Word Data created for " + Player.getUsername(), Toast.LENGTH_SHORT).show();
        }
        return playerFile;
    }


        ///Load custom words from the file for view
    private void loadCustomWords(File file) {

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",", 2); // Expecting format: word,definition
                if (parts.length == 2) {
                    customWords.add(parts[0]); //Add only the word for display
                }
            }
        } catch (Exception e) {
            Log.e("SettingsActivity", "Error loading custom words", e);
        }
    }

        /// Save a word and its definition to the file
    private void saveWordToFile(File file, String word, String definition) {

        try (FileWriter writer = new FileWriter(file, true)) {
            writer.write(word + "," + definition + "\n");
        } catch (Exception e) {
            Log.e("SettingsActivity", "Error saving word", e);
        }
    }

     /// Deletes the named word
    private void deleteWordFromFile(File file, String wordToDelete) {
        File tempFile = new File(getFilesDir(), "temp_words.txt");

        try (BufferedReader reader = new BufferedReader(new FileReader(file));
             BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile))) {

            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.startsWith(wordToDelete + ",")) {
                    writer.write(line);
                    writer.newLine();
                }
            }

            if (!file.delete() || !tempFile.renameTo(file)) {
                throw new Exception("Failed to update custom_words.txt");
            }
        } catch (Exception e) {
            Log.e("SettingsActivity", "Error deleting word", e);
        }
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
}